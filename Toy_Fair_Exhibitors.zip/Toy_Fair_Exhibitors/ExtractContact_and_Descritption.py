#using selenuium + beautiful soup
from selenium import webdriver 
import time
from bs4 import BeautifulSoup
import pandas as pd
import re
import csv

ExhData ='ExhibitorCleaned.csv'
df1=pd.read_csv(ExhData)
with open('FullContactOutput.csv','w',newline='',encoding='UTF-8') as f:
    writer=csv.writer(f)
    writer.writerow(['URL','Address','Country','Website','Phone','Description'])
iteration = 0
driver = webdriver.Chrome()
for url in df1['URL']:
    #get the html using lenium and beautiful soup
    driver.get(url)
    time.sleep(8)
    soup = BeautifulSoup(driver.page_source,'html.parser')
    #the class we want lets take the html as text, it was much easier than tags
    html=soup.find(id='js-vue-onlinecontacts')
    html = html.prettify()
    #scroll to get to description(about us)
    driver.execute_script(f"window.scrollTo(0, {1500});")
    #delay for 5 seconds to get the website to update
    time.sleep(5)
    story =soup.find(id="js-vue-description")
    if story:
        description = story.get_text()
        description = description.strip()
    else:
        description = ""
    
    #define the res
    address_pattern = r'<p class="showcase-address[^>]*>(.*?)<br/>'
    country_pattern = r'<br/>\s*([^<]+)'
    website_pattern = r'<a href="([^"]+)" target="_blank" title="Visit our website">\s*([^<]+)\s*</a>'
    phone_pattern =  r'</span>\s*([\d().+ -]+)'
    #phone_pattern =  r'</span>\s*([\d().+- ]+)'

    #create a function to extract the text we want
    def extract_info(pattern, text):
        match = re.search(pattern, text, re.DOTALL)
        #error handling
        return match.group(1).strip() if match else "Not found"

    # Extracted information
    address = extract_info(address_pattern, html)
    website = extract_info(website_pattern, html)
    phone = extract_info(phone_pattern, html)
    country = extract_info(country_pattern, html)
    # write to csv the extracted information
    with open('FullContactOutput.csv','a+',newline='',encoding='UTF-8') as f:
        writer=csv.writer(f)
        writer.writerow([url,address,country,website,phone,description])
    iteration=iteration+1
    print(iteration)
driver.quit()
#mere the data to one csv
df2 = pd.read_csv('FullContactOutput.csv')
df3 = pd.merge(df1,df2,on='URL')
df3.to_csv('ExhibitorSummary.csv')
print('Done Scraping')