#This code extracts the list of exhibitors and their urls from a dynamic site
#Cleaning must be done
from selenium import webdriver 
from selenium.webdriver.common.by import By
import time
import csv

# Connect to the website using Selenium
url = 'https://tfny2023.mapyourshow.com/8_0/explore/exhibitor-gallery.cfm?featured=false'

driver = webdriver.Chrome()

driver.get(url)

#define scrolling parameters
start_scroll = 0
end_scroll = 12000

#loop through the body height

while start_scroll < end_scroll:

    driver.execute_script(f"window.scrollTo(0, {start_scroll});")
    #delay for 5 seconds to get the website to update
    time.sleep(5)
    
    # Locate the <a> elements
    a_elements = driver.find_elements(By.TAG_NAME, "a")
    
    # Iterate through the <a> elements to get their 'href' attributes
    #write to a csv file
    with open('Exhibitor.csv','w',newline='',encoding='UTF8') as f:
        #find the elements and hyperlinks using a for loop
            for a_element in a_elements:
                hyplinks = a_element.get_attribute('href')
                text=a_element.text
                # print the elements
                print(text," ",hyplinks)
                #write to csv notice the use of []
                writer=csv.writer(f)
                writer.writerow([text,hyplinks])
    #move the starting point of next scroll
    start_scroll += 500
    print(start_scroll)
    #click the load more button (it needs its own elements)
    load_more_bs=driver.find_elements(By.CLASS_NAME,'btn-secondary')
    for load_more_b in load_more_bs:   
        if load_more_b.is_displayed() and load_more_b.is_enabled():
            load_more_b.click()
            time.sleep(5)
# Quit the Selenium driver
driver.quit()
